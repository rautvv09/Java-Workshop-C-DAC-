package com.dkte;

public class TeachingStaff extends Staff {

	int noOfHours;
	int chargesPerHour;
	
	public TeachingStaff(int id, String name,int noOfHours, int chargesPerHour) {
		super(id, name);
		this.noOfHours = noOfHours;
		this.chargesPerHour = chargesPerHour;
	}

	public TeachingStaff(int id, String name) {
		super(id, name);
	}
	
	public TeachingStaff() {
		
	}

	public int getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(int noOfHours)throws StaffException  {
		if(noOfHours<0) {
			throw new StaffException("");
		}
		this.noOfHours = noOfHours;
	}

	public int getChargesPerHour() {
		return chargesPerHour;
	}

	public void setChargesPerHour(int chargesPerHour)throws StaffException  {
		if(chargesPerHour<0)
			throw new StaffException("");
		this.chargesPerHour = chargesPerHour;
	}

	@Override
	public String toString() {
		return "\n TeachingStaff [noOfHours=" + noOfHours + ", chargesPerHour=" + chargesPerHour + ", id=" + id + ", name="
				+ name + "]";
	}
	
	
	
	
}
