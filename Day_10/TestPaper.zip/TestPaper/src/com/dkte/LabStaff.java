package com.dkte;

public class LabStaff extends Staff {

	int salary;

	public LabStaff(int id, String name, int salary) {
		super(id, name);
		this.salary = salary;
	}

	public LabStaff(int id, String name) {
		super(id, name);
	}

	public LabStaff() {
		
	}
	
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary)throws StaffException {
		if(salary<0) {
			 throw new StaffException("");
		}
     	this.salary = salary;
	}

	@Override
	public String toString() {
		return "\n LabStaff [salary=" + salary + ", id=" + id + ", name=" + name + "]";
	}
	
	
}
